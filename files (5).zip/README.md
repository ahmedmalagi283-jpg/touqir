# Mohammed Touqir Inamdar – Portfolio

Static portfolio site (HTML, CSS, JS). No build step.

## Files
- `index.html` – the page and all content
- `style.css` – styling (black and silver theme matching FIRZAQ Alpha)
- `script.js` – footer year
- `assets/logo.svg` – FA monogram, also used as favicon
- `.nojekyll` – tells GitHub Pages to serve files as-is

## Edit before publishing
Search `index.html` for `EDIT` and `YOUR-` and replace with your real details (about text, skills, LinkedIn, GitHub).

## Publish on GitHub Pages
1. Create a new public repository on GitHub. For a root address, name it `YOUR-USERNAME.github.io`.
2. Upload all files from this folder (keep the `assets` folder), or run:
   ```
   git init
   git add .
   git commit -m "Add portfolio"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```
3. In the repository go to Settings > Pages. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/` (or `/YOUR-REPO/` for other repository names).

## Custom domain (optional)
In Settings > Pages add your domain, and point a CNAME record to `YOUR-USERNAME.github.io`.
